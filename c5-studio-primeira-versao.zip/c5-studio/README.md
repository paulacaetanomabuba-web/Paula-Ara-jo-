# C5 Studio — protótipo gratuito

Aplicativo web instalável (PWA) em português do Brasil, nas cores preto, azul e vermelho.

## Publicar no GitHub Pages pelo iPhone
1. Abra seu repositório no GitHub e use **Add file > Upload files** (no Safari, pode ser necessário solicitar o site para computador).
2. Envie **os cinco arquivos** deste pacote para a raiz do repositório (não a pasta que os contém).
3. Confirme em **Commit changes**.
4. Em **Settings > Pages**, selecione **Deploy from a branch**, branch **main**, pasta **/(root)** e **Save**.
5. Aguarde a publicação e abra o endereço informado em Pages. No Safari, toque em Compartilhar > Adicionar à Tela de Início.

## Limites importantes
- **Demonstração, não sistema de produção.** Os dados são guardados apenas no localStorage do navegador e podem desaparecer.
- **Não há autenticação, contas privadas, sincronização, pagamentos online ou controle de permissões.** Não use dados reais de alunos.
- Para uso real: backend (por exemplo Supabase), autenticação com papéis e políticas RLS, tratamento adequado à LGPD, agendamentos e integração de pagamentos com provedor brasileiro. Não coloque chaves secretas no GitHub Pages.
